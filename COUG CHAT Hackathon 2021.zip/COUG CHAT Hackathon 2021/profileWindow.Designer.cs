﻿
namespace COUG_CHAT_Hackathon_2021
{
    partial class profileWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(profileWindow));
            this.pictureBoxBorder = new System.Windows.Forms.PictureBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.studentTypeLabel = new System.Windows.Forms.Label();
            this.hobbyLabel = new System.Windows.Forms.Label();
            this.majorLabel = new System.Windows.Forms.Label();
            this.nameEditButton = new System.Windows.Forms.Button();
            this.editGradButton = new System.Windows.Forms.Button();
            this.editHobbyButton = new System.Windows.Forms.Button();
            this.editMajorButton = new System.Windows.Forms.Button();
            this.discoverButton = new System.Windows.Forms.Button();
            this.signOutButton = new System.Windows.Forms.Button();
            this.viewFriendsButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.userNameLabel = new System.Windows.Forms.Label();
            this.followerLabel = new System.Windows.Forms.Label();
            this.f = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBorder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxBorder
            // 
            this.pictureBoxBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.pictureBoxBorder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBoxBorder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxBorder.Location = new System.Drawing.Point(72, 59);
            this.pictureBoxBorder.Name = "pictureBoxBorder";
            this.pictureBoxBorder.Size = new System.Drawing.Size(188, 186);
            this.pictureBoxBorder.TabIndex = 0;
            this.pictureBoxBorder.TabStop = false;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nameLabel.ForeColor = System.Drawing.Color.White;
            this.nameLabel.Location = new System.Drawing.Point(469, 108);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(112, 25);
            this.nameLabel.TabIndex = 2;
            this.nameLabel.Text = "Adam Karaki";
            // 
            // studentTypeLabel
            // 
            this.studentTypeLabel.AutoSize = true;
            this.studentTypeLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.studentTypeLabel.ForeColor = System.Drawing.Color.White;
            this.studentTypeLabel.Location = new System.Drawing.Point(469, 147);
            this.studentTypeLabel.Name = "studentTypeLabel";
            this.studentTypeLabel.Size = new System.Drawing.Size(131, 25);
            this.studentTypeLabel.TabIndex = 3;
            this.studentTypeLabel.Text = "Undergraduate";
            // 
            // hobbyLabel
            // 
            this.hobbyLabel.AutoSize = true;
            this.hobbyLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.hobbyLabel.ForeColor = System.Drawing.Color.White;
            this.hobbyLabel.Location = new System.Drawing.Point(469, 187);
            this.hobbyLabel.Name = "hobbyLabel";
            this.hobbyLabel.Size = new System.Drawing.Size(192, 75);
            this.hobbyLabel.TabIndex = 4;
            this.hobbyLabel.Text = "Hobbies: Video games\r\n                soccer\r\n                Twitch\r\n";
            // 
            // majorLabel
            // 
            this.majorLabel.AutoSize = true;
            this.majorLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.majorLabel.ForeColor = System.Drawing.Color.White;
            this.majorLabel.Location = new System.Drawing.Point(469, 274);
            this.majorLabel.Name = "majorLabel";
            this.majorLabel.Size = new System.Drawing.Size(210, 25);
            this.majorLabel.TabIndex = 5;
            this.majorLabel.Text = "Major: Computer Science";
            // 
            // nameEditButton
            // 
            this.nameEditButton.Location = new System.Drawing.Point(431, 104);
            this.nameEditButton.Name = "nameEditButton";
            this.nameEditButton.Size = new System.Drawing.Size(24, 29);
            this.nameEditButton.TabIndex = 6;
            this.nameEditButton.Text = "~";
            this.nameEditButton.UseVisualStyleBackColor = true;
            this.nameEditButton.Click += new System.EventHandler(this.nameEditButton_Click);
            // 
            // editGradButton
            // 
            this.editGradButton.Location = new System.Drawing.Point(431, 143);
            this.editGradButton.Name = "editGradButton";
            this.editGradButton.Size = new System.Drawing.Size(24, 29);
            this.editGradButton.TabIndex = 7;
            this.editGradButton.Text = "~";
            this.editGradButton.UseVisualStyleBackColor = true;
            this.editGradButton.Click += new System.EventHandler(this.editGradButton_Click);
            // 
            // editHobbyButton
            // 
            this.editHobbyButton.Location = new System.Drawing.Point(431, 187);
            this.editHobbyButton.Name = "editHobbyButton";
            this.editHobbyButton.Size = new System.Drawing.Size(24, 29);
            this.editHobbyButton.TabIndex = 8;
            this.editHobbyButton.Text = "~";
            this.editHobbyButton.UseVisualStyleBackColor = true;
            this.editHobbyButton.Click += new System.EventHandler(this.editHobbyButton_Click);
            // 
            // editMajorButton
            // 
            this.editMajorButton.Location = new System.Drawing.Point(431, 270);
            this.editMajorButton.Name = "editMajorButton";
            this.editMajorButton.Size = new System.Drawing.Size(24, 29);
            this.editMajorButton.TabIndex = 9;
            this.editMajorButton.Text = "~";
            this.editMajorButton.UseVisualStyleBackColor = true;
            this.editMajorButton.Click += new System.EventHandler(this.editMajorButton_Click);
            // 
            // discoverButton
            // 
            this.discoverButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.discoverButton.ForeColor = System.Drawing.Color.White;
            this.discoverButton.Location = new System.Drawing.Point(41, 343);
            this.discoverButton.Name = "discoverButton";
            this.discoverButton.Size = new System.Drawing.Size(126, 57);
            this.discoverButton.TabIndex = 10;
            this.discoverButton.Text = "Discover People";
            this.discoverButton.UseVisualStyleBackColor = false;
            this.discoverButton.Click += new System.EventHandler(this.discoverButton_Click);
            // 
            // signOutButton
            // 
            this.signOutButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.signOutButton.ForeColor = System.Drawing.Color.White;
            this.signOutButton.Location = new System.Drawing.Point(537, 343);
            this.signOutButton.Name = "signOutButton";
            this.signOutButton.Size = new System.Drawing.Size(123, 57);
            this.signOutButton.TabIndex = 11;
            this.signOutButton.Text = "Sign Out";
            this.signOutButton.UseVisualStyleBackColor = false;
            this.signOutButton.Click += new System.EventHandler(this.signOutButton_Click);
            // 
            // viewFriendsButton
            // 
            this.viewFriendsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.viewFriendsButton.ForeColor = System.Drawing.Color.White;
            this.viewFriendsButton.Location = new System.Drawing.Point(288, 343);
            this.viewFriendsButton.Name = "viewFriendsButton";
            this.viewFriendsButton.Size = new System.Drawing.Size(126, 57);
            this.viewFriendsButton.TabIndex = 12;
            this.viewFriendsButton.Text = "View Friends";
            this.viewFriendsButton.UseVisualStyleBackColor = false;
            this.viewFriendsButton.Click += new System.EventHandler(this.viewFriendsButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(72, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 25);
            this.label1.TabIndex = 13;
            // 
            // userNameLabel
            // 
            this.userNameLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.userNameLabel.ForeColor = System.Drawing.Color.White;
            this.userNameLabel.Location = new System.Drawing.Point(72, 19);
            this.userNameLabel.Name = "userNameLabel";
            this.userNameLabel.Size = new System.Drawing.Size(188, 25);
            this.userNameLabel.TabIndex = 14;
            // 
            // followerLabel
            // 
            this.followerLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.followerLabel.ForeColor = System.Drawing.Color.White;
            this.followerLabel.Location = new System.Drawing.Point(469, 19);
            this.followerLabel.Name = "followerLabel";
            this.followerLabel.Size = new System.Drawing.Size(131, 25);
            this.followerLabel.TabIndex = 15;
            // 
            // f
            // 
            this.f.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.f.ForeColor = System.Drawing.Color.White;
            this.f.Location = new System.Drawing.Point(111, 248);
            this.f.Name = "f";
            this.f.Size = new System.Drawing.Size(109, 32);
            this.f.TabIndex = 16;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(84, 73);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(161, 159);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(38, 33);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // profileWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(715, 443);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.f);
            this.Controls.Add(this.followerLabel);
            this.Controls.Add(this.userNameLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.viewFriendsButton);
            this.Controls.Add(this.signOutButton);
            this.Controls.Add(this.discoverButton);
            this.Controls.Add(this.editMajorButton);
            this.Controls.Add(this.editHobbyButton);
            this.Controls.Add(this.editGradButton);
            this.Controls.Add(this.nameEditButton);
            this.Controls.Add(this.majorLabel);
            this.Controls.Add(this.hobbyLabel);
            this.Controls.Add(this.studentTypeLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.pictureBoxBorder);
            this.Name = "profileWindow";
            this.Text = "profileWindow";
            this.Load += new System.EventHandler(this.profileWindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBorder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxBorder;
        private System.Windows.Forms.PictureBox myProfilePicture;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label studentTypeLabel;
        private System.Windows.Forms.Label hobbyLabel;
        private System.Windows.Forms.Label majorLabel;
        private System.Windows.Forms.Button nameEditButton;
        private System.Windows.Forms.Button editGradButton;
        private System.Windows.Forms.Button editHobbyButton;
        private System.Windows.Forms.Button editMajorButton;
        private System.Windows.Forms.Button discoverButton;
        private System.Windows.Forms.Button signOutButton;
        private System.Windows.Forms.Button viewFriendsButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label userNameLabel;
        private System.Windows.Forms.Label followerLabel;
        private System.Windows.Forms.Label g;
        private System.Windows.Forms.Label f;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}