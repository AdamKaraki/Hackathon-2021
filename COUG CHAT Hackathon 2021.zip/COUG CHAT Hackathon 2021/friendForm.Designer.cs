﻿
namespace COUG_CHAT_Hackathon_2021
{
    partial class friendForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(friendForm));
            this.friendListBox = new System.Windows.Forms.ListBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.hiRadioButton = new System.Windows.Forms.RadioButton();
            this.howRadioButton = new System.Windows.Forms.RadioButton();
            this.byeRadioButton = new System.Windows.Forms.RadioButton();
            this.hiResponseLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hiLabel = new System.Windows.Forms.Label();
            this.howLabel = new System.Windows.Forms.Label();
            this.byeLabel = new System.Windows.Forms.Label();
            this.SFMLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.viewPersonButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // friendListBox
            // 
            this.friendListBox.FormattingEnabled = true;
            this.friendListBox.ItemHeight = 20;
            this.friendListBox.Location = new System.Drawing.Point(33, 41);
            this.friendListBox.Name = "friendListBox";
            this.friendListBox.Size = new System.Drawing.Size(146, 144);
            this.friendListBox.TabIndex = 0;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nameLabel.ForeColor = System.Drawing.Color.White;
            this.nameLabel.Location = new System.Drawing.Point(63, 9);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(78, 25);
            this.nameLabel.TabIndex = 3;
            this.nameLabel.Text = "Friends: ";
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.exitButton.ForeColor = System.Drawing.Color.White;
            this.exitButton.Location = new System.Drawing.Point(256, 282);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(95, 51);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Back";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // hiRadioButton
            // 
            this.hiRadioButton.AutoSize = true;
            this.hiRadioButton.ForeColor = System.Drawing.Color.White;
            this.hiRadioButton.Location = new System.Drawing.Point(430, 56);
            this.hiRadioButton.Name = "hiRadioButton";
            this.hiRadioButton.Size = new System.Drawing.Size(53, 24);
            this.hiRadioButton.TabIndex = 13;
            this.hiRadioButton.TabStop = true;
            this.hiRadioButton.Text = "Hi !";
            this.hiRadioButton.UseVisualStyleBackColor = true;
            this.hiRadioButton.CheckedChanged += new System.EventHandler(this.hiRadioButton_CheckedChanged);
            // 
            // howRadioButton
            // 
            this.howRadioButton.AutoSize = true;
            this.howRadioButton.ForeColor = System.Drawing.Color.White;
            this.howRadioButton.Location = new System.Drawing.Point(430, 134);
            this.howRadioButton.Name = "howRadioButton";
            this.howRadioButton.Size = new System.Drawing.Size(118, 24);
            this.howRadioButton.TabIndex = 14;
            this.howRadioButton.TabStop = true;
            this.howRadioButton.Text = "how are you?";
            this.howRadioButton.UseVisualStyleBackColor = true;
            this.howRadioButton.CheckedChanged += new System.EventHandler(this.howRadioButton_CheckedChanged);
            // 
            // byeRadioButton
            // 
            this.byeRadioButton.AutoSize = true;
            this.byeRadioButton.ForeColor = System.Drawing.Color.White;
            this.byeRadioButton.Location = new System.Drawing.Point(430, 230);
            this.byeRadioButton.Name = "byeRadioButton";
            this.byeRadioButton.Size = new System.Drawing.Size(126, 44);
            this.byeRadioButton.TabIndex = 15;
            this.byeRadioButton.TabStop = true;
            this.byeRadioButton.Text = "Bye, I gotta\r\ndo homework!\r\n";
            this.byeRadioButton.UseVisualStyleBackColor = true;
            this.byeRadioButton.CheckedChanged += new System.EventHandler(this.byeRadioButton_CheckedChanged);
            // 
            // hiResponseLabel
            // 
            this.hiResponseLabel.AutoSize = true;
            this.hiResponseLabel.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.hiResponseLabel.ForeColor = System.Drawing.Color.White;
            this.hiResponseLabel.Location = new System.Drawing.Point(436, 68);
            this.hiResponseLabel.Name = "hiResponseLabel";
            this.hiResponseLabel.Size = new System.Drawing.Size(0, 23);
            this.hiResponseLabel.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(293, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 23);
            this.label1.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(-99, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 23);
            this.label2.TabIndex = 18;
            // 
            // hiLabel
            // 
            this.hiLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hiLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.hiLabel.ForeColor = System.Drawing.Color.White;
            this.hiLabel.Location = new System.Drawing.Point(444, 83);
            this.hiLabel.Name = "hiLabel";
            this.hiLabel.Size = new System.Drawing.Size(165, 35);
            this.hiLabel.TabIndex = 19;
            // 
            // howLabel
            // 
            this.howLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.howLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.howLabel.ForeColor = System.Drawing.Color.White;
            this.howLabel.Location = new System.Drawing.Point(444, 163);
            this.howLabel.Name = "howLabel";
            this.howLabel.Size = new System.Drawing.Size(165, 36);
            this.howLabel.TabIndex = 20;
            // 
            // byeLabel
            // 
            this.byeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.byeLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.byeLabel.ForeColor = System.Drawing.Color.White;
            this.byeLabel.Location = new System.Drawing.Point(444, 282);
            this.byeLabel.Name = "byeLabel";
            this.byeLabel.Size = new System.Drawing.Size(165, 34);
            this.byeLabel.TabIndex = 21;
            // 
            // SFMLabel
            // 
            this.SFMLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SFMLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SFMLabel.ForeColor = System.Drawing.Color.White;
            this.SFMLabel.Location = new System.Drawing.Point(444, 12);
            this.SFMLabel.Name = "SFMLabel";
            this.SFMLabel.Size = new System.Drawing.Size(112, 25);
            this.SFMLabel.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(352, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 20);
            this.label4.TabIndex = 23;
            this.label4.Text = "Messaging: ";
            // 
            // viewPersonButton
            // 
            this.viewPersonButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.viewPersonButton.ForeColor = System.Drawing.Color.White;
            this.viewPersonButton.Location = new System.Drawing.Point(33, 191);
            this.viewPersonButton.Name = "viewPersonButton";
            this.viewPersonButton.Size = new System.Drawing.Size(146, 29);
            this.viewPersonButton.TabIndex = 24;
            this.viewPersonButton.Text = "Display to Label";
            this.viewPersonButton.UseVisualStyleBackColor = false;
            this.viewPersonButton.Click += new System.EventHandler(this.viewPersonButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // friendForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(616, 345);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.viewPersonButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.SFMLabel);
            this.Controls.Add(this.byeLabel);
            this.Controls.Add(this.howLabel);
            this.Controls.Add(this.hiLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hiResponseLabel);
            this.Controls.Add(this.byeRadioButton);
            this.Controls.Add(this.howRadioButton);
            this.Controls.Add(this.hiRadioButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.friendListBox);
            this.Name = "friendForm";
            this.Text = "Messaging: ";
            this.Load += new System.EventHandler(this.friendForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox friendListBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.RadioButton hiRadioButton;
        private System.Windows.Forms.RadioButton howRadioButton;
        private System.Windows.Forms.RadioButton byeRadioButton;
        private System.Windows.Forms.Label hiResponseLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label hiLabel;
        private System.Windows.Forms.Label howLabel;
        private System.Windows.Forms.Label byeLabel;
        private System.Windows.Forms.Label SFMLabel;
        private System.Windows.Forms.Label sh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label owshs;
        private System.Windows.Forms.Label oshoshfshdklhfs;
        private System.Windows.Forms.Button viewPersonButton;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}